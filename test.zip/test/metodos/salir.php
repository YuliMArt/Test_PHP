<?php
session_start();
$varses=$_SESSION['username'];
if($varses == null || $varses = ''){
  header('location:../login.php');
   die();
}
session_destroy();
header('location:../login.php')
?>