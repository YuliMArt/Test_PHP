<?php	
class metodos{
		public function mostrarDatos($sql){
			$c= new conectar();
			$conexion=$c->conexion();

			$result=mysqli_query($conexion,$sql);

			return mysqli_fetch_all($result,MYSQLI_ASSOC);
		}
		public function insertarDatos($datos){
			$c= new conectar();
			$conexion=$c->conexion();

			echo  $sql="INSERT into usuarios (usuario,pass)
							values ('$datos[0]','$datos[1]')";

			return $result=mysqli_query($conexion,$sql);
		}

		public function actualizaDatosNombre($datos){
			$c= new conectar();
			$conexion=$c->conexion();

			$sql="UPDATE usuarios set usuario='$datos[0]',
										pass='$datos[1]'
								where id='$datos[2]'";
			return $result=mysqli_query($conexion,$sql);

		}
	       
    
}
 ?>