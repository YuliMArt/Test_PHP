<?php 
	require_once "../conexion.php";
    require_once "clases.php";



    if(isset($_POST['reg'])){
       $usuario=$_POST['user'];
	$passw=$_POST['pass'];

	$datos=array(
			$usuario,
			$passw
				);
	$obj= new metodos();
	if($obj->insertarDatos($datos)==1){
		header("location:../register.php");
	}else{
		echo "fallo al agregar";
	} 
    }



    if(isset($_POST['upd'])){
        $usuario=$_POST['user'];
	$passw=$_POST['pass'];
	$id=$_POST['id'];

	$datos=array(
			$usuario,
			$passw,
			$id
				);
	$obj= new metodos();

	if($obj->actualizaDatosNombre($datos)==1){
		header("location:../register.php");
	}else{
		echo "fallo al agregar";
	}
    }

    if(isset($_POST['login'])){
        $usuario=$_POST['user'];
	$passw=$_POST['pass'];
	

	$c= new conectar();
			$conexion=$c->conexion();
			 $sql="SELECT  *from usuarios where usuario='$usuario' and pass='$passw'";
             $result=mysqli_query($conexion,$sql);
             $row_cnt = $result->num_rows;
              
                if( $row_cnt == 1 ){  
                    session_start();
                    $_SESSION['username']=$usuario;
                    header("location:../register.php");
              
                }else{
               
                    header("location:../login.php");

                 
                }
               
    }

	

 ?>