<?php 
	require_once "conexion.php";
	require_once "metodos/clases.php";

 ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    
</head>
<style>
    .container{
        margin-top: 50px;
    }
</style>
<body>
<div class="container text-center">
    <h2>Login</h2>
<form action="metodos/procesos.php" method="POST">
  
    
    <input type="text" placeholder="user" value="" name="user">
 
  <br>
    <br>
    <input type="password" placeholder="Password" name="pass">
<br>
<br>
  
    <button type="submit" class="btn btn-primary mb-3" name="login">Confirm identity</button>
  
</form>
</div>



</body>
<script src="js/bootstrap.min.js"></script>
</html>