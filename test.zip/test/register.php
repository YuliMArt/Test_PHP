
<?php 
	require_once "conexion.php";
	require_once "metodos/clases.php";

 ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">

    <title>Document</title>
</head>
<body>
<nav class="navbar navbar-light bg-light">
 <div class="text-center">
 <a href="metodos/salir.php" >Salir</a>

 </div>
</nav>
<div class="container text-center r">
<h2>Registro de usuarios</h2>
<div class="con1 ">
<form action="metodos/procesos.php" method="post">


    
    <input type="text" placeholder="user" name="user" >
 
  <br>
    <br>
    <input type="password" placeholder="Password" name="pass">
<br>
<br>
    <button type="submit" class="btn btn-primary mb-3" name="reg">Registrar</button>
  
</form></div>
<hr>
<hr>
<div class="tab">

<h4>Lista de usuarios</h4>
<table class="table">


<table class="table table-hover" >
  <thead class="thead-dark">
    <tr>
    
      <th scope="col">Usuario</th>
      <th scope="col">Contraseña</th>
      <th scope="col">Operaciones</th>
      
    </tr>
  </thead>
  <tbody>

  <?php 
	$obj= new metodos();
	$sql="SELECT  *from usuarios";
	$datos=$obj->mostrarDatos($sql);

	foreach ($datos as $key ) {
 ?>
    <tr>
      <th ><?php echo $key['usuario']; ?></th>
      <td><?php echo $key['pass']; ?></td>
      <td><a href="change-password.php?id=<?php echo $key['id'] ?>">
			Editar
			</a> 
      </td>
      
    </tr>
    <?php 
	}
 ?>
  </tbody>
</table>
</div>

</div>
    
</body>
<script src="js/bootstrap.min.js"></script>

</html>