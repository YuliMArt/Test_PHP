
<?php 

session_start();
$varses=$_SESSION['username'];
if($varses == null || $varses = ''){
  header('location:login.php');
   die();
}


require_once "conexion.php";
$obj= new conectar();
$conexion=$obj->conexion();
$id=$_GET['id'];
$sql="SELECT  
        *from usuarios where id='$id'";
$result=mysqli_query($conexion,$sql);
$ver=mysqli_fetch_row($result);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<!-- Image and text -->
<nav class="navbar navbar-light bg-light">
 <div class="text-center">
 <a href="metodos/salir.php" >Salir</a>

 </div>
  
</nav>

    <div class="container text-center col-lg-4 actu">
    <form action="metodos/procesos.php" method="post">
	<input type="text" hidden="" value="<?php echo $id ?>" name="id">
	<label style="margin-right: 7px;">Usuario</label>
	
	<input type="text" name="user" value="<?php echo $ver[1] ?>">
	<p></p>
	<label style="margin-right: 7px;">Contraseña</label>
	
	<input type="text" name="pass" value="<?php echo $ver[2] ?>">
	<p></p>
    <button type="submit" class="btn btn-primary mb-3" name="upd">Actualizar</button>
</form>
    </div>
</body>
<script src="js/bootstrap.min.js"></script>
</html>